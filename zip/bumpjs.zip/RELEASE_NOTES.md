
Version 0.2.6 (February 28th 2017)
------------------------------
 * Added damage handling. an Object 
 * Added a Penetration Resolution correction in collision.js to improve the engine behavior.
 * Added setIteration() and getIteration() to Scene class. This allows to iterate several times through all collisions and improve greatly the engine behavior.
 
Version 0.2.5 (February 21th 2017)
------------------------------
 * Type6.js dependency is built separately into the dist/dependencies/ folder instead of being directly inserted into the distribution Bump.js and Bump.min.js files

Version 0.2.4 (February 11th 2017)
------------------------------
 * Added testScene() method to test collisions between 2 collision scenes
 * Updated documentation
 
Version 0.2.3 (January 30th 2017)
------------------------------
 * Updated Type6.js dependency to version 0.2.3 

Version 0.2.2 (January 18th 2017)
------------------------------
 * Fix damping setter on Physics.create() method
 
Version 0.2.1 (January 14th 2017)
------------------------------
 * Added setGravity() method

Version 0.2.0 (December 22th 2016)
------------------------------
 * Updated for open source release on GitHub
 * Code reworked
 * Dedicated website
 * Documentation
 * Examples

Version 0.1.0 (December 1st 2011)
-----------------------------
 * initial version
